class Demo {

  public static void main(String [] args ){

    int run []={50,67,87,98,66};
    int sum =0;
    for(int i=0;i<5;i++){
      sum = sum + run[i];
    }

    System.out.println("Total run = "+sum);
  }
}
