class shortDemo{

  public static void main(String args[]){
    short x=3367;
    System.out.println(x);
    x=x+10000;
    System.out.println(x);

  }
}
