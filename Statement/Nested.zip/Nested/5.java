class Demo {

  public static void main(String [] args){

    for(int i=1 ; i<=9;i++){
      if(i%3 ==0){
        System.out.println(i*i+"\t");
      }else {
        System.out.print(i*i+"\t");
      }
    }
  }
}
