class charDemo{

  public static void main(String []argd){

//    char ch='s';
      char ch = 49;
    System.out.println(ch);
  }
}
