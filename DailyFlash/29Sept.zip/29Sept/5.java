class Demo{

  public static void main(String []args){

    char arr[]={'A','B','C','D','E'};

    for(int i=0;i<5;i++){
    char a = arr[i];
    System.out.print(Character.toLowerCase(a)+" ");
    }
    System.out.println("");
  }
}
