class BoolDemo{
  public static void main(String [] args){
//    boolean b='true';
      //boolean b=1;
      boolean b=false;
    System.out.println(b);
  }
}
