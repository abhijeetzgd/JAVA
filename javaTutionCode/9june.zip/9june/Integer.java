//Byte
//-128 to 127

class IntDemo{

  public static void main(String args []){
    byte myData = 127;
    System.out.println(myData);
    myData++;
    System.out.println(myData);

  }
}
