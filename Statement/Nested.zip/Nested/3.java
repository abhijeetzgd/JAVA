class Demo {

  public static void main(String [] args){

    for(int i=1 ; i<=16;i++){
      if(i%4 ==0){
        System.out.println(i+"\t");
      }else {
        System.out.print(i+"\t");
      }
    }
  }
}
