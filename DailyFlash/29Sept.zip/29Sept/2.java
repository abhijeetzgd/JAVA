class Demo {

  public static void main(String [] args ){

    int num []={50,67,87,98,66};

    for(int i=0;i<5;i++){
      if( num[i] %2==0)
      System.out.print(num[i]+" ");

    }
    System.out.println("");

  }
}
