class floatDemo{
public static void main(String [] arggs){
//  float f = 25.5;
    float f=34.55f;
  System.out.println(f);
  double s=34.55;
System.out.println(f);
  if(f==s)
    System.out.println("BOTH VALUES ARE SAME");
  else
      System.out.println("BOTH VALUES ARE DIFFERENT");
}
}
